<template>
                <h1>departmentPage组件</h1>
            </template>

            <script>

            export default {
              name:"departmentPage",
                setup() {
                    return {
                    }
                }
            }
            </script>

            <style lang="scss" scoped>
            </style>
