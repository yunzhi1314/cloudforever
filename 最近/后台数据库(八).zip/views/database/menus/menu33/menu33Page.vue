<template>
                <h1>menu33Page组件</h1>
            </template>

            <script>

            export default {
              name:"menu33Page",
                setup() {
                    return {
                    }
                }
            }
            </script>

            <style lang="scss" scoped>
            </style>
