<template>
                <h1>stepsPage组件</h1>
            </template>

            <script>

            export default {
              name:"stepsPage",
                setup() {
                    return {
                    }
                }
            }
            </script>

            <style lang="scss" scoped>
            </style>
