<template>
                <h1>tagsPage组件</h1>
            </template>

            <script>

            export default {
              name:"tagsPage",
                setup() {
                    return {
                    }
                }
            }
            </script>

            <style lang="scss" scoped>
            </style>
