<template>
                <h1>wavesPage组件</h1>
            </template>

            <script>

            export default {
              name:"wavesPage",
                setup() {
                    return {
                    }
                }
            }
            </script>

            <style lang="scss" scoped>
            </style>
