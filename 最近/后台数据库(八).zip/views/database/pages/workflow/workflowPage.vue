<template>
                <h1>workflowPage组件</h1>
            </template>

            <script>

            export default {
              name:"workflowPage",
                setup() {
                    return {
                    }
                }
            }
            </script>

            <style lang="scss" scoped>
            </style>
