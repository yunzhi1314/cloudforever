<template>
                <h1>formI18nPage组件</h1>
            </template>

            <script>

            export default {
              name:"formI18nPage",
                setup() {
                    return {
                    }
                }
            }
            </script>

            <style lang="scss" scoped>
            </style>
