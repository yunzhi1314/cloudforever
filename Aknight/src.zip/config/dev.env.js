// 开发环境
module.exports = {
    NODE_ENV:"development",
    BASE_URL:"http://8.134.179.237:8080/"
}