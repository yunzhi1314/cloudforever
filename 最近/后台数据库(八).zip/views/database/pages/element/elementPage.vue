<template>
                <h1>elementPage组件</h1>
            </template>

            <script>

            export default {
              name:"elementPage",
                setup() {
                    return {
                    }
                }
            }
            </script>

            <style lang="scss" scoped>
            </style>
