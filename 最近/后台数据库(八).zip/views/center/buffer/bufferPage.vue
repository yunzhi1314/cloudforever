<template>
  <div></div>
</template>

<script>
import {centerMenu} from "@/api/arknight/centerPage/routes"

export default {
  name: "bufferPage",
  setup() {
    centerMenu()

    return {
    }
  }
}
</script>

<style lang="scss" scoped></style>
