<template>
                <h1>treePage组件</h1>
            </template>

            <script>

            export default {
              name:"treePage",
                setup() {
                    return {
                    }
                }
            }
            </script>

            <style lang="scss" scoped>
            </style>
