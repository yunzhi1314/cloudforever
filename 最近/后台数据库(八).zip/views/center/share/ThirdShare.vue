<template>
  <h1>ThirdShare.vue组件</h1>
</template>

<script>

export default {
  name: "ThirdShare",
  setup() {
    return {
    }
  }
}
</script>

<style lang="scss" scoped></style>
