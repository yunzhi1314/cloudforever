<template>
                <h1>webPage组件</h1>
            </template>

            <script>

            export default {
              name:"webPage",
                setup() {
                    return {
                    }
                }
            }
            </script>

            <style lang="scss" scoped>
            </style>
