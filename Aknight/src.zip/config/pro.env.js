// 生产环境
module.exports = {
    NODE_ENV:"production",
    BASE_URL:"http://8.134.179.237:8080/"
}