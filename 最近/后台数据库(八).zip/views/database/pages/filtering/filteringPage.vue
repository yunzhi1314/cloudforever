<template>
                <h1>filteringPage组件</h1>
            </template>

            <script>

            export default {
              name:"filteringPage",
                setup() {
                    return {
                    }
                }
            }
            </script>

            <style lang="scss" scoped>
            </style>
