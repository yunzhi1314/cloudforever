<template>
                <h1>dragPage组件</h1>
            </template>

            <script>

            export default {
              name:"dragPage",
                setup() {
                    return {
                    }
                }
            }
            </script>

            <style lang="scss" scoped>
            </style>
