<template>
                <h1>gridLayoutPage组件</h1>
            </template>

            <script>

            export default {
              name:"gridLayoutPage",
                setup() {
                    return {
                    }
                }
            }
            </script>

            <style lang="scss" scoped>
            </style>
