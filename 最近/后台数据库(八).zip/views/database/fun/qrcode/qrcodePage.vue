<template>
                <h1>qrcodePage组件</h1>
            </template>

            <script>

            export default {
              name:"qrcodePage",
                setup() {
                    return {
                    }
                }
            }
            </script>

            <style lang="scss" scoped>
            </style>
