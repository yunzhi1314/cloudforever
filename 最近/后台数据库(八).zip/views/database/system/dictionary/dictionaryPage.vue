<template>
                <h1>dictionaryPage组件</h1>
            </template>

            <script>

            export default {
              name:"dictionaryPage",
                setup() {
                    return {
                    }
                }
            }
            </script>

            <style lang="scss" scoped>
            </style>
