<template>
                <h1>listAdaptPage组件</h1>
            </template>

            <script>

            export default {
              name:"listAdaptPage",
                setup() {
                    return {
                    }
                }
            }
            </script>

            <style lang="scss" scoped>
            </style>
