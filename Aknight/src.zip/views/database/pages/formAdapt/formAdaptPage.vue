<template>
                <h1>formAdaptPage组件</h1>
            </template>

            <script>

            export default {
              name:"formAdaptPage",
                setup() {
                    return {
                    }
                }
            }
            </script>

            <style lang="scss" scoped>
            </style>
