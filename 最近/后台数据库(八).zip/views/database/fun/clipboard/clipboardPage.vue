<template>
                <h1>clipboardPage组件</h1>
            </template>

            <script>

            export default {
              name:"clipboardPage",
                setup() {
                    return {
                    }
                }
            }
            </script>

            <style lang="scss" scoped>
            </style>
