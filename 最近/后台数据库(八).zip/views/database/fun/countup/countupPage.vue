<template>
                <h1>countupPage组件</h1>
            </template>

            <script>

            export default {
              name:"countupPage",
                setup() {
                    return {
                    }
                }
            }
            </script>

            <style lang="scss" scoped>
            </style>
