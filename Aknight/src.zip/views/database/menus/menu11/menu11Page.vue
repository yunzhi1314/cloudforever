<template>
                <h1>menu11Page组件</h1>
            </template>

            <script>

            export default {
              name:"menu11Page",
                setup() {
                    return {
                    }
                }
            }
            </script>

            <style lang="scss" scoped>
            </style>
