<template>
                <h1>splitpanesPage组件</h1>
            </template>

            <script>

            export default {
              name:"splitpanesPage",
                setup() {
                    return {
                    }
                }
            }
            </script>

            <style lang="scss" scoped>
            </style>
