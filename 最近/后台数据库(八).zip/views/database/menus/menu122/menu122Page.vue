<template>
                <h1>menu122Page组件</h1>
            </template>

            <script>

            export default {
              name:"menu122Page",
                setup() {
                    return {
                    }
                }
            }
            </script>

            <style lang="scss" scoped>
            </style>
