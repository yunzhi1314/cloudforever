<template>
                <h1>waterfallPage组件</h1>
            </template>

            <script>

            export default {
              name:"waterfallPage",
                setup() {
                    return {
                    }
                }
            }
            </script>

            <style lang="scss" scoped>
            </style>
