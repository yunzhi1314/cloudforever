<template>
                <h1>previewPage组件</h1>
            </template>

            <script>

            export default {
              name:"previewPage",
                setup() {
                    return {
                    }
                }
            }
            </script>

            <style lang="scss" scoped>
            </style>
