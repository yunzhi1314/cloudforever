module.exports = {
    NODE_ENV:"development",
    API_ROOT: "http://8.134.179.237:8080/"
}