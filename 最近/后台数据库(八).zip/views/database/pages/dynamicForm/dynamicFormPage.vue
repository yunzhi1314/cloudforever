<template>
                <h1>dynamicFormPage组件</h1>
            </template>

            <script>

            export default {
              name:"dynamicFormPage",
                setup() {
                    return {
                    }
                }
            }
            </script>

            <style lang="scss" scoped>
            </style>
