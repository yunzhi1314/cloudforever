<template>
                <h1>cropperPage组件</h1>
            </template>

            <script>

            export default {
              name:"cropperPage",
                setup() {
                    return {
                    }
                }
            }
            </script>

            <style lang="scss" scoped>
            </style>
