<template>
                <h1>lazyImgPage组件</h1>
            </template>

            <script>

            export default {
              name:"lazyImgPage",
                setup() {
                    return {
                    }
                }
            }
            </script>

            <style lang="scss" scoped>
            </style>
