<template>
                <h1>PersonalList.vue组件</h1>
            </template>

            <script>

            export default {
              name:"PersonalList",
                setup() {
                    return {
                    }
                }
            }
            </script>

            <style lang="scss" scoped>
            </style>
