<template>
                <h1>buttonPage组件</h1>
            </template>

            <script>

            export default {
              name:"buttonPage",
                setup() {
                    return {
                    }
                }
            }
            </script>

            <style lang="scss" scoped>
            </style>
