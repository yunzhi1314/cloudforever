<template>
                <h1>iconfontPage组件</h1>
            </template>

            <script>

            export default {
              name:"iconfontPage",
                setup() {
                    return {
                    }
                }
            }
            </script>

            <style lang="scss" scoped>
            </style>
