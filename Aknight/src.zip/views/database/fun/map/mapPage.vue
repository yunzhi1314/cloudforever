<template>
                <h1>mapPage组件</h1>
            </template>

            <script>

            export default {
              name:"mapPage",
                setup() {
                    return {
                    }
                }
            }
            </script>

            <style lang="scss" scoped>
            </style>
