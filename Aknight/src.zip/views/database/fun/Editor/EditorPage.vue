<template>
                <h1>EditorPage组件</h1>
            </template>

            <script>

            export default {
              name:"EditorPage",
                setup() {
                    return {
                    }
                }
            }
            </script>

            <style lang="scss" scoped>
            </style>
